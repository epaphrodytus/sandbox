# Python Packaging Tutorial

Following along the simple tutorial in [Python's Packaging User Guide](https://packaging.python.org/en/latest/tutorials/packaging-projects/)
